/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material3

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable

/**
 * Properties used to customize the behavior of a [ModalWideNavigationRail].
 *
 * @param shouldDismissOnBackPress Whether the modal navigation rail can be dismissed by pressing
 *   the back button. If true, pressing the back button will call onDismissRequest.
 */
@Immutable
public actual class ModalWideNavigationRailProperties
public actual constructor(public actual val shouldDismissOnBackPress: Boolean)

internal actual fun createDefaultModalWideNavigationRailProperties():
    ModalWideNavigationRailProperties = implementedInJetBrainsFork()

@Composable
internal actual fun ModalWideNavigationRailDialog(
    onDismissRequest: () -> Unit,
    properties: ModalWideNavigationRailProperties,
    onPredictiveBack: (Float) -> Unit,
    onPredictiveBackCancelled: () -> Unit,
    predictiveBackState: RailPredictiveBackState,
    content: @Composable () -> Unit,
): Unit = implementedInJetBrainsFork()
