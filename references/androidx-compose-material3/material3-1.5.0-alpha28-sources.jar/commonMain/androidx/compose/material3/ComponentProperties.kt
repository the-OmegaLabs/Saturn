/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material3

internal class ComponentProperties(
    val checkboxProperties: CheckboxProperties = CheckboxProperties.Default,
    val radioButtonProperties: RadioButtonProperties = RadioButtonProperties.Default,
    val searchBarProperties: SearchBarProperties = SearchBarProperties.Default,
    val appBarWithSearchBarProperties: AppBarWithSearchProperties =
        AppBarWithSearchProperties.Default,
    // TODO(b/543061101): Add properties for components.
) {
    companion object {
        val Default = ComponentProperties()
    }
}

internal class CheckboxProperties(val style: CheckboxStyle = CheckboxStyle.Default) {
    companion object {
        val Default = CheckboxProperties()
    }
}

internal class RadioButtonProperties(val style: RadioButtonStyle = RadioButtonStyle.Default) {
    companion object {
        val Default = RadioButtonProperties()
    }
}

internal class SearchBarProperties(val style: SearchBarStyle = SearchBarStyle.Default) {
    companion object {
        val Default = SearchBarProperties()
    }
}

internal class AppBarWithSearchProperties(
    val style: AppBarWithSearchStyle = AppBarWithSearchStyle.Default
) {
    companion object {
        val Default = AppBarWithSearchProperties()
    }
}
