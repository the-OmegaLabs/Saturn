/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.material3

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.internal.DropdownMenuPositionProvider
import androidx.compose.material3.tokens.ElevationTokens
import androidx.compose.material3.tokens.ListTokens
import androidx.compose.material3.tokens.MenuTokens
import androidx.compose.material3.tokens.SegmentedMenuTokens
import androidx.compose.material3.tokens.ShapeTokens
import androidx.compose.material3.tokens.StandardMenuTokens
import androidx.compose.material3.tokens.VibrantMenuTokens
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.PopupProperties
import kotlin.jvm.JvmName

/** Contains default values used for [DropdownMenu] and [DropdownMenuItem]. */
public object MenuDefaults {
    /** The default [PopupProperties] used in [DropdownMenu] and [DropdownMenuPopup] */
    public val DefaultMenuProperties: PopupProperties = PopupProperties(focusable = true)

    /** The default tonal elevation for a menu. */
    public val TonalElevation: Dp = ElevationTokens.Level0

    /** The default shadow elevation for a menu. */
    public val ShadowElevation: Dp = MenuTokens.ContainerElevation

    /** The default leading icon size for a menu item. */
    public val LeadingIconSize: Dp = SegmentedMenuTokens.ItemLeadingIconSize

    /** The default trailing icon size for a menu item. */
    public val TrailingIconSize: Dp
        get() =
            if (shouldUsePrecisionPointerComponentSizing.value) {
                24.dp
            } else {
                SegmentedMenuTokens.ItemTrailingIconSize
            }

    /** The default shape for a menu. */
    public val shape: Shape
        @Composable get() = MenuTokens.ContainerShape.value

    /** The default container color for a menu. */
    public val containerColor: Color
        @Composable get() = MenuTokens.ContainerColor.value

    /**
     * The standard default container color for a group within a menu.
     *
     * Menus have two color options: standard (surface based) vibrant (tertiary based)
     *
     * These mappings provide options for lower or higher visual emphasis. Vibrant menus are more
     * prominent so should be used sparingly.
     */
    // TODO update with tokens when available

    public val groupStandardContainerColor: Color
        @Composable get() = StandardMenuTokens.ContainerColor.value

    /**
     * The vibrant default container color for a group within a menu.
     *
     * Menus have two color options: standard (surface based) vibrant (tertiary based)
     *
     * These mappings provide options for lower or higher visual emphasis. Vibrant menus are more
     * prominent so should be used sparingly.
     */
    // TODO update with tokens when available

    public val groupVibrantContainerColor: Color
        @Composable get() = VibrantMenuTokens.ContainerColor.value

    /** The default shape for the leading group of a menu. */
    public val leadingGroupShape: Shape
        @Composable
        get() =
            RoundedCornerShape(
                topStart = ShapeTokens.CornerValueLarge,
                topEnd = ShapeTokens.CornerValueLarge,
                bottomStart = ShapeTokens.CornerValueSmall,
                bottomEnd = ShapeTokens.CornerValueSmall,
            )

    /** The default shape for the middle group of a menu. */
    public val middleGroupShape: Shape
        @Composable get() = SegmentedMenuTokens.GroupShape.value

    /** The default shape for the trailing group of a menu. */
    public val trailingGroupShape: Shape
        @Composable
        get() =
            RoundedCornerShape(
                topStart = ShapeTokens.CornerValueSmall,
                topEnd = ShapeTokens.CornerValueSmall,
                bottomStart = ShapeTokens.CornerValueLarge,
                bottomEnd = ShapeTokens.CornerValueLarge,
            )

    /** The default shape for the leading item of a menu or group. */
    public val leadingItemShape: Shape
        @Composable
        get() =
            RoundedCornerShape(
                topStart = ShapeTokens.CornerValueMedium,
                topEnd = ShapeTokens.CornerValueMedium,
                bottomStart = ShapeTokens.CornerValueExtraSmall,
                bottomEnd = ShapeTokens.CornerValueExtraSmall,
            )

    /** The default shape for the middle item of a menu or group. */
    public val middleItemShape: Shape
        @Composable get() = SegmentedMenuTokens.ItemShape.value

    /** The default shape for the trailing item of a menu or group. */
    public val trailingItemShape: Shape
        @Composable
        get() =
            RoundedCornerShape(
                topStart = ShapeTokens.CornerValueExtraSmall,
                topEnd = ShapeTokens.CornerValueExtraSmall,
                bottomStart = ShapeTokens.CornerValueMedium,
                bottomEnd = ShapeTokens.CornerValueMedium,
            )

    /** The default shape for a standalone item of a menu or group. */
    public val standaloneItemShape: Shape
        @Composable get() = middleItemShape

    /** The selected shape for items of a group. */
    public val selectedItemShape: Shape
        @Composable get() = SegmentedMenuTokens.ItemSelectedShape.value

    /** The default shape for a standalone group of a menu. */
    public val standaloneGroupShape: Shape
        @Composable get() = SegmentedMenuTokens.ContainerShape.value

    /** The shape for a group of a menu that is no longer being hovered. */
    public val inactiveGroupShape: Shape
        @Composable get() = SegmentedMenuTokens.InactiveContainerShape.value

    /** The default spacing between each menu group. Usually used in a [Spacer]'s height */
    public val GroupSpacing: Dp = SegmentedMenuTokens.SegmentedGap

    /**
     * The default padding for a [HorizontalDivider] used in a menu group. Use this padding value in
     * a [HorizontalDivider]'s padding modifier.
     */
    public val HorizontalDividerPadding: PaddingValues =
        PaddingValues(horizontal = 12.dp, vertical = 2.dp)

    /**
     * The default horizontal padding for a menu group label. Please see
     * [MenuDefaults.DropdownMenuGroupLabel].
     */
    public val DropdownMenuGroupLabelHorizontalPadding: PaddingValues =
        PaddingValues(start = 12.dp, end = 4.dp)

    /**
     * A [MenuGroupShapes] constructor that the group in [index] should have when there are [count]
     * groups in the menu.
     *
     * @param index the index for this group in the menu.
     * @param count the count of groups in this menu.
     */
    @Composable
    public fun groupShape(index: Int, count: Int): MenuGroupShapes {
        if (count == 1) {
            return MaterialTheme.shapes.defaultMenuStandaloneGroupShapes
        }

        return when (index) {
            0 -> MaterialTheme.shapes.defaultMenuLeadingGroupShapes
            count - 1 -> MaterialTheme.shapes.defaultMenuTrailingGroupShapes
            else -> MaterialTheme.shapes.defaultMenuMiddleGroupShapes
        }
    }

    /**
     * A [MenuItemShapes] constructor that the item in [index] should have when there are [count]
     * items in the menu or group. If a [DropdownMenuGroup] is used, please pass the number of items
     * within the group as [count]. If no [DropdownMenuGroup] is used, please pass the number of
     * items in the entire menu as [count].
     *
     * @param index the index for this item in the menu or group.
     * @param count the count of items in this menu or group.
     */
    @Composable
    public fun itemShape(index: Int, count: Int): MenuItemShapes {
        if (count == 1) {
            return MaterialTheme.shapes.defaultMenuStandaloneItemShapes
        }

        return when (index) {
            0 -> MaterialTheme.shapes.defaultMenuLeadingItemShapes
            count - 1 -> MaterialTheme.shapes.defaultMenuTrailingItemShapes
            else -> MaterialTheme.shapes.defaultMenuMiddleItemShapes
        }
    }

    /**
     * Creates a [MenuItemColors] that represents the default text and icon colors used in a
     * [DropdownMenuItemContent].
     */
    @Composable
    public fun itemColors(): MenuItemColors = MaterialTheme.colorScheme.defaultMenuItemColors

    /**
     * Creates a [MenuItemShapes] that represents the shapes used in a [CheckableDropdownMenuItem]
     * or [SelectableDropdownMenuItem], allowing for overrides.
     *
     * There is a convenience function that can be used to easily determine the shape to be used at
     * [MenuDefaults.itemShape].
     *
     * @param shape the shape when unselected. It uses [middleItemShape] as the default if null is
     *   provided.
     * @param selectedShape the shape when selected. It uses [selectedItemShape] as the default if
     *   null is provided.
     */
    @Composable
    public fun itemShapes(shape: Shape? = null, selectedShape: Shape? = null): MenuItemShapes =
        MaterialTheme.shapes.defaultMenuStandaloneItemShapes.copy(
            shape = shape,
            selectedShape = selectedShape,
        )

    /**
     * Creates a [MenuItemShapes] that represents the shapes used in a [CheckableDropdownMenuItem]
     * or [SelectableDropdownMenuItem].
     *
     * There is a convenience function that can be used to easily determine the shape to be used at
     * [MenuDefaults.itemShape].
     *
     * This [MenuItemShapes] has [MenuDefaults.standaloneItemShape] as the shape and
     * [MenuDefaults.selectedItemShape] as the selected shape.
     */
    @Composable
    public fun itemShapes(): MenuItemShapes = MaterialTheme.shapes.defaultMenuStandaloneItemShapes

    /**
     * Creates a [MenuGroupShapes] that represents the default shapes used in a [DropdownMenuGroup],
     * allowing for overrides.
     *
     * There is a convenience function that can be used to easily determine the shape to be used at
     * [MenuDefaults.groupShape].
     *
     * @param shape the default shape of the group. It uses [standaloneGroupShape] as the default if
     *   null is provided.
     * @param inactiveShape the shape when no longer being hovered. It uses [inactiveGroupShape] as
     *   the default if null is provided.
     */
    @Composable
    public fun groupShapes(shape: Shape? = null, inactiveShape: Shape? = null): MenuGroupShapes =
        MaterialTheme.shapes.defaultMenuStandaloneGroupShapes.copy(
            shape = shape,
            inactiveShape = inactiveShape,
        )

    /**
     * Creates a [MenuGroupShapes] that represents the default shapes used in a [DropdownMenuGroup].
     *
     * This [MenuGroupShapes] has [MenuDefaults.standaloneGroupShape] as the shape and
     * [MenuDefaults.inactiveGroupShape] as the inactive shape, the inactive shape is the shape of
     * the group after it is no longer being hovered.
     */
    @Composable
    public fun groupShapes(): MenuGroupShapes =
        MaterialTheme.shapes.defaultMenuStandaloneGroupShapes

    /**
     * The default label recommended to be used within a [DropdownMenuGroup].
     *
     * Labels can be used to categorize parts of the group or the entire group
     *
     * @param modifier the [Modifier] to be applied to this label.
     * @param contentAlignment the alignment of the label's content.
     * @param padding the padding applied to the label's content.
     * @param content the content of the label.
     */
    @Composable
    public fun DropdownMenuGroupLabel(
        modifier: Modifier = Modifier,
        contentAlignment: Alignment = Alignment.CenterStart,
        padding: PaddingValues = DropdownMenuGroupLabelHorizontalPadding,
        content: @Composable () -> Unit,
    ) {
        // TODO replace the typography with token when available
        ProvideTextStyle(MaterialTheme.typography.labelLarge) {
            Box(
                modifier =
                    modifier
                        .sizeIn(
                            minWidth = DropdownMenuItemDefaultMinWidth,
                            maxWidth = DropdownMenuItemDefaultMaxWidth,
                            minHeight = DropdownMenuGroupDefaultMinHeight,
                        )
                        .padding(padding),
                contentAlignment = contentAlignment,
            ) {
                content()
            }
        }
    }

    /**
     * The default horizontal padding for a menu group trailing label. Please see
     * [MenuDefaults.DropdownMenuItemTrailingLabel].
     */
    public val DropdownMenuItemTrailingLabelHorizontalPadding: PaddingValues
        get() =
            if (shouldUsePrecisionPointerComponentSizing.value) {
                PaddingValues(start = 0.dp, end = 6.dp)
            } else {
                PaddingValues(all = 0.dp)
            }

    /**
     * The default trailing label recommended to be used within a [DropdownMenuItem] which can be
     * passed to its trailingIcon param.
     *
     * @param modifier the [Modifier] to be applied to this dropdown menu item trailing label.
     * @param padding the padding applied to the label's content.
     * @param content the content of the label.
     */
    @Composable
    public fun DropdownMenuItemTrailingLabel(
        modifier: Modifier = Modifier,
        padding: PaddingValues = DropdownMenuItemTrailingLabelHorizontalPadding,
        content: @Composable () -> Unit,
    ) {
        // TODO replace the typography with token when available
        ProvideTextStyle(MaterialTheme.typography.labelLarge) {
            Box(modifier = modifier.padding(padding)) { content() }
        }
    }

    /**
     * Creates a [MenuItemColors] that represents the default text and icon colors used in a
     * [DropdownMenuItemContent].
     *
     * @param textColor the text color of this [DropdownMenuItemContent] when enabled
     * @param leadingIconColor the leading icon color of this [DropdownMenuItemContent] when enabled
     * @param trailingIconColor the trailing icon color of this [DropdownMenuItemContent] when
     *   enabled
     * @param disabledTextColor the text color of this [DropdownMenuItemContent] when not enabled
     * @param disabledLeadingIconColor the leading icon color of this [DropdownMenuItemContent] when
     *   not enabled
     * @param disabledTrailingIconColor the trailing icon color of this [DropdownMenuItemContent]
     *   when not enabled
     */
    @Composable
    public fun itemColors(
        textColor: Color = Color.Unspecified,
        leadingIconColor: Color = Color.Unspecified,
        trailingIconColor: Color = Color.Unspecified,
        disabledTextColor: Color = Color.Unspecified,
        disabledLeadingIconColor: Color = Color.Unspecified,
        disabledTrailingIconColor: Color = Color.Unspecified,
    ): MenuItemColors =
        MaterialTheme.colorScheme.defaultMenuItemColors.copy(
            textColor = textColor,
            leadingIconColor = leadingIconColor,
            trailingIconColor = trailingIconColor,
            disabledTextColor = disabledTextColor,
            disabledLeadingIconColor = disabledLeadingIconColor,
            disabledTrailingIconColor = disabledTrailingIconColor,
        )

    /**
     * Creates a [MenuItemColors] that represents the default text, icon, and container colors used
     * in a vibrant color variant [DropdownMenuItem].
     */
    @Composable
    public fun itemVibrantColors(): MenuItemColors =
        MaterialTheme.colorScheme.defaultMenuItemVibrantColors

    /**
     * Creates a [MenuItemColors] that represents the default text, icon, and container colors used
     * in a vibrant color variant [DropdownMenuItem]. This uses the [Color.Unspecified] to mean “use
     * the value from the source”.
     *
     * @param textColor the text color of this [DropdownMenuItem] when enabled
     * @param leadingIconColor the leading icon color of this [DropdownMenuItem] when enabled
     * @param trailingIconColor the trailing icon color of this [DropdownMenuItem] when enabled
     * @param disabledTextColor the text color of this [DropdownMenuItem] when not enabled
     * @param disabledLeadingIconColor the leading icon color of this [DropdownMenuItem] when not
     *   enabled
     * @param disabledTrailingIconColor the trailing icon color of this [DropdownMenuItem] when not
     *   enabled
     */
    @Composable
    public fun itemVibrantColors(
        textColor: Color = Color.Unspecified,
        leadingIconColor: Color = Color.Unspecified,
        trailingIconColor: Color = Color.Unspecified,
        disabledTextColor: Color = Color.Unspecified,
        disabledLeadingIconColor: Color = Color.Unspecified,
        disabledTrailingIconColor: Color = Color.Unspecified,
    ): MenuItemColors =
        MaterialTheme.colorScheme.defaultMenuItemVibrantColors.copy(
            textColor = textColor,
            leadingIconColor = leadingIconColor,
            trailingIconColor = trailingIconColor,
            disabledTextColor = disabledTextColor,
            disabledLeadingIconColor = disabledLeadingIconColor,
            disabledTrailingIconColor = disabledTrailingIconColor,
        )

    /**
     * Creates a [SelectableMenuItemColors] that represents the default text, icon, and container
     * colors used in a standard color variant [SelectableDropdownMenuItem] or
     * [CheckableDropdownMenuItem]. This uses the [Color.Unspecified] to mean “use the value from
     * the source”.
     *
     * When the item is disabled, disabled colors take priority over selected colors.
     *
     * @param textColor the text color of this menu item when enabled and unselected/unchecked
     * @param containerColor the container color of this menu item when enabled and
     *   unselected/unchecked
     * @param leadingIconColor the leading icon color of this menu item when enabled
     * @param trailingContentColor the trailing content color of this menu item when enabled
     * @param disabledTextColor the text color of this menu item when not enabled; takes priority if
     *   the item is both selected/checked and disabled
     * @param disabledContainerColor the container color of this menu item when not enabled; takes
     *   priority if the item is both selected/checked and disabled
     * @param disabledLeadingIconColor the leading icon color of this menu item when not enabled;
     *   takes priority if the item is both selected/checked and disabled
     * @param disabledTrailingContentColor the trailing content color of this menu item when not
     *   enabled; takes priority if the item is both selected/checked and disabled
     * @param selectedTextColor the text color of this menu item when enabled and selected/checked
     * @param selectedContainerColor the container color of this menu item when enabled and
     *   selected/checked
     * @param selectedLeadingIconColor the leading icon color of this menu item when enabled and
     *   selected/checked
     * @param selectedTrailingContentColor the trailing content color of this menu item when enabled
     *   and selected/checked
     */
    @Composable
    public fun selectableItemColors(
        textColor: Color = Color.Unspecified,
        containerColor: Color = Color.Unspecified,
        leadingIconColor: Color = Color.Unspecified,
        trailingContentColor: Color = Color.Unspecified,
        disabledTextColor: Color = Color.Unspecified,
        disabledContainerColor: Color = Color.Unspecified,
        disabledLeadingIconColor: Color = Color.Unspecified,
        disabledTrailingContentColor: Color = Color.Unspecified,
        selectedTextColor: Color = Color.Unspecified,
        selectedContainerColor: Color = Color.Unspecified,
        selectedLeadingIconColor: Color = Color.Unspecified,
        selectedTrailingContentColor: Color = Color.Unspecified,
    ): SelectableMenuItemColors =
        MaterialTheme.colorScheme.defaultMenuSelectableItemColors.copy(
            textColor = textColor,
            containerColor = containerColor,
            leadingIconColor = leadingIconColor,
            trailingContentColor = trailingContentColor,
            disabledTextColor = disabledTextColor,
            disabledContainerColor = disabledContainerColor,
            disabledLeadingIconColor = disabledLeadingIconColor,
            disabledTrailingContentColor = disabledTrailingContentColor,
            selectedTextColor = selectedTextColor,
            selectedContainerColor = selectedContainerColor,
            selectedLeadingIconColor = selectedLeadingIconColor,
            selectedTrailingContentColor = selectedTrailingContentColor,
        )

    /**
     * Delegates to selectableItemColors to resolve unspecified tokens against MenuTokens
     * (StandardMenuTokens), then adapts the resolved colors into MenuItemColors for binary
     * compatibility.
     */
    @Composable
    internal fun selectableItemColorsLegacy(): MenuItemColors {
        val colors = selectableItemColors()
        return MenuItemColors(
            textColor = colors.textColor,
            leadingIconColor = colors.leadingIconColor,
            trailingIconColor = colors.trailingContentColor,
            disabledTextColor = colors.disabledTextColor,
            disabledLeadingIconColor = colors.disabledLeadingIconColor,
            disabledTrailingIconColor = colors.disabledTrailingContentColor,
            containerColor = colors.containerColor,
            disabledContainerColor = colors.disabledContainerColor,
        )
    }

    /**
     * Creates a [MenuItemColors] that represents the default text, icon, and container colors used
     * in a standard color variant [DropdownMenuItem]. This uses the Color.Unspecified to mean “use
     * the value from the source”
     *
     * Delegates to [selectableItemColors] to resolve unspecified tokens against MenuTokens
     * (StandardMenuTokens), then adapts the resolved colors into [MenuItemColors] for binary
     * compatibility.
     *
     * @param textColor the text color of this [DropdownMenuItem] when enabled
     * @param containerColor the container color of this [DropdownMenuItem] when enabled and
     *   unselected
     * @param leadingIconColor the leading icon color of this [DropdownMenuItem] when enabled
     * @param trailingIconColor the trailing icon color of this [DropdownMenuItem] when enabled
     * @param disabledTextColor the text color of this [DropdownMenuItem] when not enabled
     * @param disabledContainerColor the container color of this [DropdownMenuItem] when not enabled
     * @param disabledLeadingIconColor the leading icon color of this [DropdownMenuItem] when not
     *   enabled
     * @param disabledTrailingIconColor the trailing icon color of this [DropdownMenuItem] when not
     *   enabled
     * @param selectedContainerColor the container color of this [DropdownMenuItem] when enabled and
     *   selected
     * @param selectedTextColor the text color of this [DropdownMenuItem] when enabled and selected
     * @param selectedLeadingIconColor the leading icon color of this [DropdownMenuItem] when
     *   enabled and selected
     * @param selectedTrailingIconColor the trailing icon color of this [DropdownMenuItem] when
     *   enabled and selected
     */
    @Deprecated("Maintained for binary compatibility.", level = DeprecationLevel.HIDDEN)
    @JvmName("selectableItemColors")
    @Composable
    public fun selectableItemColorsLegacy(
        textColor: Color = Color.Unspecified,
        containerColor: Color = Color.Unspecified,
        leadingIconColor: Color = Color.Unspecified,
        trailingIconColor: Color = Color.Unspecified,
        disabledTextColor: Color = Color.Unspecified,
        disabledContainerColor: Color = Color.Unspecified,
        disabledLeadingIconColor: Color = Color.Unspecified,
        disabledTrailingIconColor: Color = Color.Unspecified,
        selectedContainerColor: Color = Color.Unspecified,
        selectedTextColor: Color = Color.Unspecified,
        selectedLeadingIconColor: Color = Color.Unspecified,
        selectedTrailingIconColor: Color = Color.Unspecified,
    ): MenuItemColors {
        val colors =
            selectableItemColors(
                textColor = textColor,
                containerColor = containerColor,
                leadingIconColor = leadingIconColor,
                trailingContentColor = trailingIconColor,
                disabledTextColor = disabledTextColor,
                disabledContainerColor = disabledContainerColor,
                disabledLeadingIconColor = disabledLeadingIconColor,
                disabledTrailingContentColor = disabledTrailingIconColor,
                selectedTextColor = selectedTextColor,
                selectedContainerColor = selectedContainerColor,
                selectedLeadingIconColor = selectedLeadingIconColor,
                selectedTrailingContentColor = selectedTrailingIconColor,
            )
        return MenuItemColors(
            textColor = colors.textColor,
            leadingIconColor = colors.leadingIconColor,
            trailingIconColor = colors.trailingContentColor,
            disabledTextColor = colors.disabledTextColor,
            disabledLeadingIconColor = colors.disabledLeadingIconColor,
            disabledTrailingIconColor = colors.disabledTrailingContentColor,
            containerColor = colors.containerColor,
            disabledContainerColor = colors.disabledContainerColor,
        )
    }

    /**
     * Creates a [SelectableMenuItemColors] that represents the default text, icon, and container
     * colors used in a vibrant color variant [SelectableDropdownMenuItem] or
     * [CheckableDropdownMenuItem]. This uses the [Color.Unspecified] to mean “use the value from
     * the source”.
     *
     * When the item is disabled, disabled colors take priority over selected colors.
     *
     * @param textColor the text color of this menu item when enabled and unselected/unchecked
     * @param containerColor the container color of this menu item when enabled and
     *   unselected/unchecked
     * @param leadingIconColor the leading icon color of this menu item when enabled
     * @param trailingContentColor the trailing content color of this menu item when enabled
     * @param disabledTextColor the text color of this menu item when not enabled; takes priority if
     *   the item is both selected/checked and disabled
     * @param disabledContainerColor the container color of this menu item when not enabled; takes
     *   priority if the item is both selected/checked and disabled
     * @param disabledLeadingIconColor the leading icon color of this menu item when not enabled;
     *   takes priority if the item is both selected/checked and disabled
     * @param disabledTrailingContentColor the trailing content color of this menu item when not
     *   enabled; takes priority if the item is both selected/checked and disabled
     * @param selectedTextColor the text color of this menu item when enabled and selected/checked
     * @param selectedContainerColor the container color of this menu item when enabled and
     *   selected/checked
     * @param selectedLeadingIconColor the leading icon color of this menu item when enabled and
     *   selected/checked
     * @param selectedTrailingContentColor the trailing content color of this menu item when enabled
     *   and selected/checked
     */
    @Composable
    public fun selectableItemVibrantColors(
        textColor: Color = Color.Unspecified,
        containerColor: Color = Color.Unspecified,
        leadingIconColor: Color = Color.Unspecified,
        trailingContentColor: Color = Color.Unspecified,
        disabledTextColor: Color = Color.Unspecified,
        disabledContainerColor: Color = Color.Unspecified,
        disabledLeadingIconColor: Color = Color.Unspecified,
        disabledTrailingContentColor: Color = Color.Unspecified,
        selectedTextColor: Color = Color.Unspecified,
        selectedContainerColor: Color = Color.Unspecified,
        selectedLeadingIconColor: Color = Color.Unspecified,
        selectedTrailingContentColor: Color = Color.Unspecified,
    ): SelectableMenuItemColors =
        MaterialTheme.colorScheme.defaultMenuSelectableItemVibrantColors.copy(
            textColor = textColor,
            containerColor = containerColor,
            leadingIconColor = leadingIconColor,
            trailingContentColor = trailingContentColor,
            disabledTextColor = disabledTextColor,
            disabledContainerColor = disabledContainerColor,
            disabledLeadingIconColor = disabledLeadingIconColor,
            disabledTrailingContentColor = disabledTrailingContentColor,
            selectedTextColor = selectedTextColor,
            selectedContainerColor = selectedContainerColor,
            selectedLeadingIconColor = selectedLeadingIconColor,
            selectedTrailingContentColor = selectedTrailingContentColor,
        )

    /**
     * Creates a [MenuItemColors] that represents the default text, icon, and container colors used
     * in a vibrant color variant [DropdownMenuItem]. This uses the Color.Unspecified to mean “use
     * the value from the source”
     *
     * @param textColor the text color of this [DropdownMenuItem] when enabled
     * @param containerColor the container color of this [DropdownMenuItem] when enabled and
     *   unselected
     * @param leadingIconColor the leading icon color of this [DropdownMenuItem] when enabled
     * @param trailingIconColor the trailing icon color of this [DropdownMenuItem] when enabled
     * @param disabledTextColor the text color of this [DropdownMenuItem] when not enabled
     * @param disabledContainerColor the container color of this [DropdownMenuItem] when not enabled
     * @param disabledLeadingIconColor the leading icon color of this [DropdownMenuItem] when not
     *   enabled
     * @param disabledTrailingIconColor the trailing icon color of this [DropdownMenuItem] when not
     *   enabled
     * @param selectedContainerColor the container color of this [DropdownMenuItem] when enabled and
     *   selected
     * @param selectedTextColor the text color of this [DropdownMenuItem] when enabled and selected
     * @param selectedLeadingIconColor the leading icon color of this [DropdownMenuItem] when
     *   enabled and selected
     * @param selectedTrailingIconColor the trailing icon color of this [DropdownMenuItem] when
     *   enabled and selected
     */
    @Deprecated("Maintained for binary compatibility.", level = DeprecationLevel.HIDDEN)
    @JvmName("selectableItemVibrantColors")
    @Composable
    public fun selectableItemVibrantColorsLegacy(
        textColor: Color = Color.Unspecified,
        containerColor: Color = Color.Unspecified,
        leadingIconColor: Color = Color.Unspecified,
        trailingIconColor: Color = Color.Unspecified,
        disabledTextColor: Color = Color.Unspecified,
        disabledContainerColor: Color = Color.Unspecified,
        disabledLeadingIconColor: Color = Color.Unspecified,
        disabledTrailingIconColor: Color = Color.Unspecified,
        selectedContainerColor: Color = Color.Unspecified,
        selectedTextColor: Color = Color.Unspecified,
        selectedLeadingIconColor: Color = Color.Unspecified,
        selectedTrailingIconColor: Color = Color.Unspecified,
    ): MenuItemColors {
        val colors =
            selectableItemVibrantColors(
                textColor = textColor,
                containerColor = containerColor,
                leadingIconColor = leadingIconColor,
                trailingContentColor = trailingIconColor,
                disabledTextColor = disabledTextColor,
                disabledContainerColor = disabledContainerColor,
                disabledLeadingIconColor = disabledLeadingIconColor,
                disabledTrailingContentColor = disabledTrailingIconColor,
                selectedTextColor = selectedTextColor,
                selectedContainerColor = selectedContainerColor,
                selectedLeadingIconColor = selectedLeadingIconColor,
                selectedTrailingContentColor = selectedTrailingIconColor,
            )
        return MenuItemColors(
            textColor = colors.textColor,
            leadingIconColor = colors.leadingIconColor,
            trailingIconColor = colors.trailingContentColor,
            disabledTextColor = colors.disabledTextColor,
            disabledLeadingIconColor = colors.disabledLeadingIconColor,
            disabledTrailingIconColor = colors.disabledTrailingContentColor,
            containerColor = colors.containerColor,
            disabledContainerColor = colors.disabledContainerColor,
        )
    }

    /**
     * Creates and remembers a [DropdownMenuPopupPositionProvider] that positions a dropdown menu
     * relative to its anchor.
     *
     * @param dropdownMenuAnchorPosition The positioning strategy to use. This determines the
     *   preferred alignment of the menu relative to the anchor. There are predefined positions,
     *   please see [MenuAnchorPosition.Above], [MenuAnchorPosition.Below],
     *   [MenuAnchorPosition.Left], [MenuAnchorPosition.Right], [MenuAnchorPosition.Start], and
     *   [MenuAnchorPosition.End]. A custom positioning can also be defined through the use of
     *   [MenuAnchorPosition.Custom].
     * @param offset An optional [DpOffset] to apply to the final calculated position.
     */
    @Composable
    public fun rememberDropdownMenuPopupPositionProvider(
        dropdownMenuAnchorPosition: MenuAnchorPosition,
        offset: DpOffset = DpOffset(0.dp, 0.dp),
    ): DropdownMenuPopupPositionProvider {
        val density = LocalDensity.current
        return remember(dropdownMenuAnchorPosition, offset, density) {
            DropdownMenuPositionProvider(
                dropdownMenuAnchorPosition = dropdownMenuAnchorPosition,
                contentOffset = offset,
                density = density,
            )
        }
    }

    internal val ColorScheme.defaultMenuItemColors: MenuItemColors
        get() {
            return defaultMenuItemColorsCached
                ?: MenuItemColors(
                        containerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        textColor = fromToken(ListTokens.ItemLabelTextColor),
                        leadingIconColor = fromToken(ListTokens.ItemLeadingIconColor),
                        trailingIconColor = fromToken(ListTokens.ItemTrailingIconColor),
                        disabledTextColor =
                            fromToken(ListTokens.ItemDisabledLabelTextColor)
                                .copy(alpha = ListTokens.ItemDisabledLabelTextOpacity),
                        disabledLeadingIconColor =
                            fromToken(ListTokens.ItemDisabledLeadingIconColor)
                                .copy(alpha = ListTokens.ItemDisabledLeadingIconOpacity),
                        disabledTrailingIconColor =
                            fromToken(ListTokens.ItemDisabledTrailingIconColor)
                                .copy(alpha = ListTokens.ItemDisabledTrailingIconOpacity),
                    )
                    .also { defaultMenuItemColorsCached = it }
        }

    internal val ColorScheme.defaultMenuItemVibrantColors: MenuItemColors
        get() {
            return defaultMenuItemVibrantColorsCached
                ?: MenuItemColors(
                        textColor = fromToken(VibrantMenuTokens.ItemLabelTextColor),
                        containerColor = fromToken(VibrantMenuTokens.ContainerColor),
                        leadingIconColor = fromToken(VibrantMenuTokens.ItemLeadingIconColor),
                        trailingIconColor = fromToken(VibrantMenuTokens.ItemTrailingIconColor),
                        disabledTextColor =
                            fromToken(VibrantMenuTokens.ItemDisabledLabelTextColor)
                                .copy(alpha = VibrantMenuTokens.ItemDisabledLabelTextOpacity),
                        disabledLeadingIconColor =
                            fromToken(VibrantMenuTokens.ItemDisabledLeadingIconColor)
                                .copy(alpha = VibrantMenuTokens.ItemDisabledLeadingIconOpacity),
                        disabledTrailingIconColor =
                            fromToken(VibrantMenuTokens.ItemDisabledTrailingIconColor)
                                .copy(alpha = VibrantMenuTokens.ItemDisabledTrailingIconOpacity),
                        disabledContainerColor = fromToken(VibrantMenuTokens.ContainerColor),
                    )
                    .also { defaultMenuItemVibrantColorsCached = it }
        }

    internal val ColorScheme.defaultMenuSelectableItemColors: SelectableMenuItemColors
        get() {
            return defaultMenuSelectableItemColorsCached
                ?: SelectableMenuItemColors(
                        textColor = fromToken(StandardMenuTokens.ItemLabelTextColor),
                        containerColor = fromToken(StandardMenuTokens.ContainerColor),
                        leadingIconColor = fromToken(StandardMenuTokens.ItemLeadingIconColor),
                        trailingContentColor = fromToken(StandardMenuTokens.ItemTrailingIconColor),
                        disabledTextColor =
                            fromToken(StandardMenuTokens.ItemDisabledLabelTextColor)
                                .copy(alpha = StandardMenuTokens.ItemDisabledLabelTextOpacity),
                        disabledLeadingIconColor =
                            fromToken(StandardMenuTokens.ItemDisabledLeadingIconColor)
                                .copy(alpha = StandardMenuTokens.ItemDisabledLeadingIconOpacity),
                        disabledTrailingContentColor =
                            fromToken(StandardMenuTokens.ItemDisabledTrailingIconColor)
                                .copy(alpha = StandardMenuTokens.ItemDisabledTrailingIconOpacity),
                        disabledContainerColor = fromToken(StandardMenuTokens.ContainerColor),
                        selectedTextColor =
                            fromToken(StandardMenuTokens.ItemSelectedLabelTextColor),
                        selectedContainerColor =
                            fromToken(StandardMenuTokens.ItemSelectedContainerColor),
                        selectedLeadingIconColor =
                            fromToken(StandardMenuTokens.ItemSelectedLeadingIconColor),
                        selectedTrailingContentColor =
                            fromToken(StandardMenuTokens.ItemSelectedTrailingIconColor),
                    )
                    .also { defaultMenuSelectableItemColorsCached = it }
        }

    internal val ColorScheme.defaultMenuSelectableItemVibrantColors: SelectableMenuItemColors
        get() {
            return defaultMenuSelectableItemVibrantColorsCached
                ?: SelectableMenuItemColors(
                        textColor = fromToken(VibrantMenuTokens.ItemLabelTextColor),
                        containerColor = fromToken(VibrantMenuTokens.ContainerColor),
                        leadingIconColor = fromToken(VibrantMenuTokens.ItemLeadingIconColor),
                        trailingContentColor = fromToken(VibrantMenuTokens.ItemTrailingIconColor),
                        disabledTextColor =
                            fromToken(VibrantMenuTokens.ItemDisabledLabelTextColor)
                                .copy(alpha = VibrantMenuTokens.ItemDisabledLabelTextOpacity),
                        disabledLeadingIconColor =
                            fromToken(VibrantMenuTokens.ItemDisabledLeadingIconColor)
                                .copy(alpha = VibrantMenuTokens.ItemDisabledLeadingIconOpacity),
                        disabledTrailingContentColor =
                            fromToken(VibrantMenuTokens.ItemDisabledTrailingIconColor)
                                .copy(alpha = VibrantMenuTokens.ItemDisabledTrailingIconOpacity),
                        disabledContainerColor = fromToken(VibrantMenuTokens.ContainerColor),
                        selectedTextColor = fromToken(VibrantMenuTokens.ItemSelectedLabelTextColor),
                        selectedContainerColor =
                            fromToken(VibrantMenuTokens.ItemSelectedContainerColor),
                        selectedLeadingIconColor =
                            fromToken(VibrantMenuTokens.ItemSelectedLeadingIconColor),
                        selectedTrailingContentColor =
                            fromToken(VibrantMenuTokens.ItemSelectedTrailingIconColor),
                    )
                    .also { defaultMenuSelectableItemVibrantColorsCached = it }
        }

    /** Default horizontal arrangement for a menu item. */
    public val DropdownMenuItemHorizontalArrangement: Arrangement.Horizontal
        get() = itemHorizontalArrangement()

    internal fun itemHorizontalArrangement(
        hasLeadingIcon: Boolean = true,
        hasTrailingIcon: Boolean = true,
    ): Arrangement.Horizontal {
        val spacing = if (shouldUsePrecisionPointerComponentSizing.value) 12.dp else 8.dp
        return MenuArrangement(spacing, hasLeadingIcon, hasTrailingIcon)
    }

    /** Default padding used for [DropdownMenuItem]. */
    public val DropdownMenuItemContentPadding: PaddingValues =
        PaddingValues(horizontal = DropdownMenuItemHorizontalPadding, vertical = 0.dp)

    private val SelectableItemVerticalPadding = 12.dp

    /**
     * Default padding used for [SelectableDropdownMenuItem] and [CheckableDropdownMenuItem] (or
     * [DropdownMenuItem] with custom shapes).
     */
    public val DropdownMenuSelectableItemContentPadding: PaddingValues
        get() =
            if (shouldUsePrecisionPointerComponentSizing.value) {
                PaddingValues(
                    start = 16.dp,
                    end = 10.dp,
                    top = SelectableItemVerticalPadding,
                    bottom = SelectableItemVerticalPadding,
                )
            } else {
                PaddingValues(
                    horizontal = DropdownMenuItemHorizontalPadding,
                    vertical = SelectableItemVerticalPadding,
                )
            }

    /** Default padding used for [DropdownMenuGroup]. */
    public val DropdownMenuGroupContentPadding: PaddingValues =
        PaddingValues(horizontal = 0.dp, vertical = DropdownMenuGroupVerticalPadding)

    internal val dropdownMenuIconTextPadding
        get() = if (shouldUsePrecisionPointerComponentSizing.value) 12.dp else 8.dp

    internal val Shapes.defaultMenuStandaloneItemShapes: MenuItemShapes
        get() {
            return defaultMenuStandaloneItemShapesCached
                ?: MenuItemShapes(
                        shape = fromToken(SegmentedMenuTokens.ItemShape),
                        selectedShape = fromToken(SegmentedMenuTokens.ItemSelectedShape),
                    )
                    .also { defaultMenuStandaloneItemShapesCached = it }
        }

    internal val Shapes.defaultMenuLeadingItemShapes: MenuItemShapes
        get() {
            return defaultMenuLeadingItemShapesCached
                ?: MenuItemShapes(
                        shape =
                            RoundedCornerShape(
                                topStart = ShapeTokens.CornerValueMedium,
                                topEnd = ShapeTokens.CornerValueMedium,
                                bottomStart = ShapeTokens.CornerValueExtraSmall,
                                bottomEnd = ShapeTokens.CornerValueExtraSmall,
                            ),
                        selectedShape = fromToken(SegmentedMenuTokens.ItemSelectedShape),
                    )
                    .also { defaultMenuLeadingItemShapesCached = it }
        }

    internal val Shapes.defaultMenuMiddleItemShapes: MenuItemShapes
        get() {
            return defaultMenuMiddleItemShapesCached
                ?: MenuItemShapes(
                        shape = fromToken(SegmentedMenuTokens.ItemShape),
                        selectedShape = fromToken(SegmentedMenuTokens.ItemSelectedShape),
                    )
                    .also { defaultMenuMiddleItemShapesCached = it }
        }

    internal val Shapes.defaultMenuTrailingItemShapes: MenuItemShapes
        get() {
            return defaultMenuTrailingItemShapesCached
                ?: MenuItemShapes(
                        shape =
                            RoundedCornerShape(
                                topStart = ShapeTokens.CornerValueExtraSmall,
                                topEnd = ShapeTokens.CornerValueExtraSmall,
                                bottomStart = ShapeTokens.CornerValueMedium,
                                bottomEnd = ShapeTokens.CornerValueMedium,
                            ),
                        selectedShape = fromToken(SegmentedMenuTokens.ItemSelectedShape),
                    )
                    .also { defaultMenuTrailingItemShapesCached = it }
        }

    internal val Shapes.defaultMenuStandaloneGroupShapes: MenuGroupShapes
        get() {
            return defaultMenuStandaloneGroupShapesCached
                ?: MenuGroupShapes(
                        shape = fromToken(SegmentedMenuTokens.ContainerShape),
                        inactiveShape = fromToken(SegmentedMenuTokens.InactiveContainerShape),
                    )
                    .also { defaultMenuStandaloneGroupShapesCached = it }
        }

    internal val Shapes.defaultMenuLeadingGroupShapes: MenuGroupShapes
        get() {
            return defaultMenuLeadingGroupShapesCached
                ?: MenuGroupShapes(
                        shape =
                            RoundedCornerShape(
                                topStart = ShapeTokens.CornerValueLarge,
                                topEnd = ShapeTokens.CornerValueLarge,
                                bottomStart = ShapeTokens.CornerValueSmall,
                                bottomEnd = ShapeTokens.CornerValueSmall,
                            ),
                        inactiveShape = fromToken(SegmentedMenuTokens.InactiveContainerShape),
                    )
                    .also { defaultMenuLeadingGroupShapesCached = it }
        }

    internal val Shapes.defaultMenuMiddleGroupShapes: MenuGroupShapes
        get() {
            return defaultMenuMiddleGroupShapesCached
                ?: MenuGroupShapes(
                        shape = fromToken(SegmentedMenuTokens.GroupShape),
                        inactiveShape = fromToken(SegmentedMenuTokens.InactiveContainerShape),
                    )
                    .also { defaultMenuMiddleGroupShapesCached = it }
        }

    internal val Shapes.defaultMenuTrailingGroupShapes: MenuGroupShapes
        get() {
            return defaultMenuTrailingGroupShapesCached
                ?: MenuGroupShapes(
                        shape =
                            RoundedCornerShape(
                                topStart = ShapeTokens.CornerValueSmall,
                                topEnd = ShapeTokens.CornerValueSmall,
                                bottomStart = ShapeTokens.CornerValueLarge,
                                bottomEnd = ShapeTokens.CornerValueLarge,
                            ),
                        inactiveShape = fromToken(SegmentedMenuTokens.InactiveContainerShape),
                    )
                    .also { defaultMenuTrailingGroupShapesCached = it }
        }
}
